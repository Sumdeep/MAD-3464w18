/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4;

/**
 *
 * @author DELL
 */
public class Student {
    String name;
    int percentage;
    int studentID;
    
    Student(){
        this.name = "Unknown";
        this.percentage = 0;
        this.studentID = 0;
        
    }
    Student(String name, int percentage, int studentID){
        this.name = name;
        this.percentage = percentage;
        this.studentID = studentID;
        
    }
    void setname(String Name){
        this.name = Name;
        
    }
    String getname(){
        return this.name;
    }
    
    void setpercentage(int Percent){
        this.percentage = Percent;
    }
    int getpercentage(){
        return this.percentage;
    }
    void setstudentID(int sID){
        this.studentID = sID;
        
    }
    int studentID(){
        return this.studentID;
}
    void displayInfo(){
        System.out.print("Name : " + this.name + "\n Percentage :" + this.percentage + "\n StudentID :" + this.studentID);
        
    }
}
